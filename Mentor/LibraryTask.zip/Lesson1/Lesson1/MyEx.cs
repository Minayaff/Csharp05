﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lessson21
{
    public class MyEx
    {
        public static void OddLine()
        {
            Console.WriteLine("------------------------------------------------------");
        }

        public static void EvenLine()
        {
            Console.WriteLine("=======================================================");
        }

        public static void ShowMessange(string msg)
        {
            Console.WriteLine("=========> : " + msg);
        }
        public static void ShowMessange(string msg,string parmentr)
        {
            Console.WriteLine(parmentr + " ==> : " + msg);
        }
        public static string InputString(string msg)
        {
            Console.Write(msg + " <<< : ");
            return Console.ReadLine();//a <<< : 
        }
        public static int InputInt(string msg)
        {
            Console.Write(msg + " <<< : ");
            return int.Parse(Console.ReadLine());//a <<< : 
        }

    }
}
