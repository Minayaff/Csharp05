﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1
{
    public class Book
    {
        public int Id = 0;
        public static int Count = 10;

        public Book(int pageCount,string name,string author)
        {

            this.Name = name;
            this.Author = author;
            this.PageCount = pageCount;

            // Static Element // Ramdada daima mövcudur
            Count = Count + 1;
            // Non Static Element // Yaradılan anda Dəşklik qeydə alinir
            this.Id = Count;

            this.Code = name.Substring(0, 2) + Id;

        }

        public string Code;


        public int PageCount;
        public string Name;
        public string Author;

    }
}
