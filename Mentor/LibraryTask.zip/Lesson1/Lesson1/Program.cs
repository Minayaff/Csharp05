﻿using Lessson21;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1
{

    internal class Program
    {
        static void Main(string[] args)
        {
            MyEx.EvenLine();// ==
            Book book = new Book(7555, "CSharp PRoduction", "Zaleddin eldorado");
            //MyEx.ShowMessange(Book.Count.ToString(), book.Name);//CSharp PRoduction ==> Count
            //MyEx.OddLine();//---
            //MyEx.ShowMessange(book.Id.ToString(), book.Name);

            //Console.WriteLine();

            Book book1 = new Book(1355, "Re CSharp Production 2", "Zaleddin all do 2");
            //MyEx.ShowMessange(Book.Count.ToString(), book1.Name);
            //MyEx.OddLine();//---
            //MyEx.ShowMessange(book1.Id.ToString(), book1.Name);

            //Console.WriteLine();

            Book book2 = new Book(255, "Pre CSharp PRoduction 3", "Zaleddin 3");
            //MyEx.ShowMessange(Book.Count.ToString(), book2.Name);
            //MyEx.OddLine();//---
            //MyEx.ShowMessange(book2.Id.ToString(), book2.Name);

            #region Static Emement 
            //MyEx.EvenLine();// ===

            //MyEx.ShowMessange(Book.Count.ToString(), book.Name);
            //MyEx.ShowMessange(book.Id.ToString(), book.Name);
            //MyEx.OddLine();//--

            //MyEx.ShowMessange(Book.Count.ToString(), book1.Name);
            //MyEx.ShowMessange(book1.Id.ToString(), book1.Name);
            //MyEx.OddLine();//--

            //MyEx.ShowMessange(Book.Count.ToString(), book2.Name);
            //MyEx.ShowMessange(book2.Id.ToString(), book2.Name);
            //MyEx.OddLine();//--
            #endregion

            #region Code Show

            //MyEx.EvenLine();// ===

            //MyEx.ShowMessange(book.Code, book.Name);
            //MyEx.OddLine();//--

            //MyEx.ShowMessange(book1.Code, book1.Name);
            //MyEx.OddLine();//--

            //MyEx.ShowMessange(book2.Code, book2.Name);
            //MyEx.OddLine();//--
            #endregion

            #region Library
            Book book3 = new Book(200, "Html Development", "Elcan");
            Book book4 = new Book(350, "Css Development", "Elcan4");
            Book book5 = new Book(100, "PHP Production", "Elcan4");
            Book book6 = new Book(100, "Python Development", "Elcan4");

            List<Book> books = new List<Book>();// Listə (Kitab Paketi)
            books.Add(book);
            books.Add(book1);
            books.Add(book2);
            books.Add(book3);
            books.Add(book4);
            books.Add(book5);
            books.Add(book6);


            Library progaming = new Library();

            progaming.books = books;

            // progaming.RemoveAllBooksByName("Dev");

            //var shearchResault = progaming.FindAllBooksByName("Dev");

            //var searchRes = progaming.SearchBooks("2");

            //var searchRes = progaming.FindAllBooksByPageCount(500,200);

            //foreach (var item in searchRes)
            //{
            //    MyEx.ShowMessange(item.Name);
            //}
            int id = 11;

            var resaultBook = progaming.SearchBookById(id);
            Console.WriteLine(resaultBook.Name);
            progaming.RemoveById(id);

            var resaultBook1 = progaming.SearchBookById(id);
            //Console.WriteLine(resaultBook1.Name);
            #endregion

        }
    }
}
