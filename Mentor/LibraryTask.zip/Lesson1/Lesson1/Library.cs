﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson1
{
    public class Library
    {
        public List<Book> books;

        public Library()
        {
            books = new List<Book>();
        }

        public List<Book> FindAllBooksByName(string name)
        {
            List<Book> resault = new List<Book>();//  List
            foreach (var book in this.books)
            {
                if (book.Name.ToLower().Contains(name.ToLower()))
                {
                    resault.Add(book);
                }
            }

            return resault;
        }

        public void RemoveAllBooksByName(string name)
        {
            var searchResault = FindAllBooksByName(name);

            foreach (var book in searchResault)
            {
                books.Remove(book);
            }
            //books.RemoveAll(x=>x.Name.ToLower().Contains(name.ToLower()));

        }

        public List<Book> SearchBooks(string info)
        {
            List<Book> resault = new List<Book>();//  List
            foreach (var book in this.books)
            {
                if (book.Name.ToLower().Contains(info.ToLower()) ||
                    book.Author.ToLower().Contains(info.ToLower()) ||
                    book.PageCount.ToString().ToLower().Contains(info.ToLower())
                    )
                {
                    resault.Add(book);
                }
            }
            return resault;
        }
        public List<Book> FindAllBooksByPageCount(int max, int min)
        {
            List<Book> resault = new List<Book>();
            foreach (var book in this.books)
            {
                if(book.PageCount <= max && book.PageCount >= min)
                {
                    resault.Add(book);
                }
            }
            return resault;
        }

        public void RemoveById(int id)
        {

            var book = SearchBookById(id);    
            books.Remove(book);

        }

        public Book SearchBookById(int id)
        {
            foreach (var book in books)
            {
                if(id == book.Id)
                {
                    return book;
                }
            }
            return null;
        }
    }
}
